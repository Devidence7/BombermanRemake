#Autores: 
|        Autores       |    NIA   |
|:--------------------:|----------|
| Víctor M. Lafuente   |  747325  |
| Alonso Muñoz         |  745016  |
| José M. Romero       |  740914  |

# Horas dedicadas:
#### En Horas:
|                   |    Parte 1    |                |       |       |    Parte 2    |                |       |       |    Parte 3    |                |       |       |   | Total |
|:-----------------:|:-------------:|:--------------:|:-----:|-------|:-------------:|:--------------:|:-----:|-------|:-------------:|:--------------:|:-----:|-------|---|-------|
|                   | Documenteción | Implementación | Debug | TOTAL | Documenteción | Implementación | Debug | TOTAL | Documenteción | Implementación | Debug | TOTAL |   |       |
| Víctor M Lafuente |       0       |        0.5     |  2.5  | 3     |     0.5       |       0.25     |   0   | 0.75  |     0.25      |        0.5     |  0.5  | 1.25  |   | 5     |
|    Alonso Muñoz   |       3       |        0.5     |  3,5  | 7     |     0.5       |       0.25     |   0   | 0.75  |     0.25      |        0.5     |  0.5  | 1.25  |   | 9     |
|   José M. Romero  |       1       |        0.5     |  3,5  | 5     |     0.5       |       0.25     |   0   | 0.75  |     0.25      |        0.5     |  0.5  | 1.25  |   | 7     |
|                   |               |                |       |       |               |                |       |       |               |                |       |       |   | 21    |

# Notas de implementación
- Tanto en Phong.html como en normalMapping.html, se ha establecido un valor mínimo de luz ambiente si el ángulo de incidencia de la luz respecto a la normal del vertice es 
aproximadamente perpendicular.

